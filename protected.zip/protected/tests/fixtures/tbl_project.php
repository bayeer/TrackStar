<?php

return array(
    'qwerty'=>array(
        'name' => 'test project 1',
        'description' => 'test project description',
        'create_time' => '2012-01-01 00:00:00',
        'create_user_id' => '1',
        'update_time' => '2012-01-01 00:00:00',
        'update_user_id' => '1',
	),
);